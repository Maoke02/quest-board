const ID = "quest-board";
const CH = `module.${ID}`;
const { ApplicationV2, HandlebarsApplicationMixin, DialogV2 } = foundry.applications.api;
const TYPES = { common: "Common", uncommon: "Uncommon", rare: "Rare", veryrare: "Very Rare", epic: "Epic", legendary: "Legendary", mythic: "Mythic", artifact: "Artifact" };
const LEGACY_TYPES = { request: "common", repeat: "uncommon", elite: "rare" };
const qualOf = q => (TYPES[q.type] ? q.type : LEGACY_TYPES[q.type] ?? "common");
const CURRENCIES = ["pp", "gp", "ep", "sp", "cp"];
const OBSERVER = () => CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER;

const Q = () => game.settings.get(ID, "quests");
const S = () => game.settings.get(ID, "state");
const LOOT = () => game.settings.get(ID, "loot");
const esc = s => String(s ?? "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const scopeOf = q => (q.scope === "personal" ? "personal" : "party");
const bucketOf = (q, uid) => (scopeOf(q) === "personal" ? uid : "party");
const activeCount = b => Object.values(b ?? {}).filter(s => s.status === "active").length;
const fmtItems = items => (items ?? []).map(i => ({ ...i, x: i.qty > 1 ? `×${i.qty}` : "" }));
const itemLabel = i => `${i.name}${i.qty > 1 ? ` ×${i.qty}` : ""}`;

/* ---------- Quest model: a quest is a chain of steps, each step has one or more objectives ---------- */
const secretOf = q => !!(q.secret ?? q.hidden);
const visibleTo = q => game.user.isGM || !secretOf(q) || !!q.revealed;
const needed = o => Math.max(1, Math.floor(Number(o.required)) || 1);
const isOpen = o => !o.secret || !!o.revealed;
const blankObj = () => ({ text: "", required: 1, secret: false });
const blankStage = () => ({ name: "", desc: "", objectives: [blankObj()] });

/* Quests made before chains existed have no `stages`; treat them as a single step. */
function stagesOf(q) {
  if (q.stages?.length) return q.stages;
  const text = q.cond || "Complete the task";
  return [{ name: text, desc: "", objectives: [{ text, required: q.required || 1 }] }];
}
const stageIndex = (q, st) => Math.min(Math.max(0, Number(st?.stage) || 0), stagesOf(q).length - 1);
const getProg = (st, i) => (Array.isArray(st?.progress) ? (st.progress[i] ?? 0) : (i === 0 ? (Number(st?.progress) || 0) : 0));
const zeros = stage => stage.objectives.map(() => 0);
function ensureProg(st, n) {
  if (!Array.isArray(st.progress)) st.progress = [Number(st.progress) || 0];
  while (st.progress.length < n) st.progress.push(0);
  return st.progress;
}
/* A step is finished when every objective the players can see is done (unrevealed secrets don't block). */
function stageMet(q, st) {
  const stage = stagesOf(q)[stageIndex(q, st)];
  const open = stage.objectives.map((o, i) => ({ o, i })).filter(({ o }) => isOpen(o));
  return open.length > 0 && open.every(({ o, i }) => getProg(st, i) >= needed(o));
}

let board = null;
let lootWin = null;
let logWin = null;
let fx = null;

/* Everything that writes world data runs on the GM's client, one job at a time. */
let queue = Promise.resolve();
const enqueue = fn => (queue = queue.then(fn).catch(e => console.error(`${ID} |`, e)));

/* The party = each player's assigned character (falls back to player-owned characters). */
function partyActors() {
  const found = new Map();
  for (const u of game.users) if (!u.isGM && u.character) found.set(u.character.id, u.character);
  if (!found.size) for (const a of game.actors) if (a.type === "character" && a.hasPlayerOwner) found.set(a.id, a);
  return [...found.values()];
}

/* What the detail panel shows for the selected quest. */
function detailOf(q, state, st, isGM) {
  const stages = stagesOf(q), last = stages.length - 1;
  const done = st?.status === "done";
  const si = done ? last : stageIndex(q, st);
  const stage = stages[si];
  const objectives = stage.objectives.map((o, i) => {
    const req = needed(o), value = done ? req : Math.min(getProg(st, i), req);
    return { i, text: o.text, required: req, value, pct: Math.round(value / req * 100), done: value >= req, secret: !!o.secret && !o.revealed, open: isOpen(o) };
  }).filter(o => isGM || o.open);

  const chain = stages.length > 1;
  const shown = isGM || done ? stages.length : si + 1;
  const steps = stages.slice(0, shown).map((s, i) => ({ label: s.name || `Step ${i + 1}`, state: done || i < si ? "done" : i === si ? "current" : "future" }));
  const more = stages.length - shown;

  const takers = Object.entries(state).filter(([, b]) => b[q.id]?.status === "active").map(([bucket, b]) => {
    const s = b[q.id], ti = stageIndex(q, s), ts = stages[ti];
    return {
      bucket, name: bucket === "party" ? "Party" : (game.users.get(bucket)?.name ?? "?"),
      step: chain ? `Step ${ti + 1}: ${ts.name}` : "",
      objs: ts.objectives.map((o, i) => ({ i, bucket, text: o.text, secret: !!o.secret && !o.revealed, value: getProg(s, i), required: needed(o), auto: !!o.track?.uuid }))
    };
  });
  const secrets = [];
  stages.forEach((s, si2) => s.objectives.forEach((o, oi) => {
    if (o.secret) secrets.push({ s: si2, o: oi, step: chain ? si2 + 1 : "", text: o.text, revealed: !!o.revealed });
  }));

  const cur = game.settings.get(ID, "currency"), pen = q.penalty ?? {};
  const penaltyLines = !isGM && q.penaltyHidden ? [] : [pen.gold ? `${pen.gold} ${cur}` : "", ...(pen.items ?? []).map(itemLabel), pen.text].filter(Boolean);
  return {
    penaltyLines, failConds: (q.failWhen ?? []).map(f => f.text).filter(Boolean),
    giverLock: !isGM && !!q.reportToGiver && si === last, giverName: q.giverActor?.name || q.giver || "the quest giver",
    objectives, chain, steps, moreLabel: more > 0 ? `${more} more step${more > 1 ? "s" : ""}` : "",
    stageName: stage.name, stageDesc: stage.desc, stageNo: si + 1, stageCount: stages.length,
    met: !done && st?.status === "active" && stageMet(q, st), isLast: si === last, takers, secrets
  };
}

/* ---------- Sound effects and board music ---------- */
const SFX = { accept: "sfxAccept", progress: "sfxProgress", complete: "sfxComplete", fail: "sfxFail" };
const audioApi = () => foundry.audio?.AudioHelper ?? globalThis.AudioHelper;
let boardMusic = null;
let musicToken = 0;
let progSnap = null;

function playSfx(kind) {
  try {
    const src = game.settings.get(ID, SFX[kind] ?? "");
    if (!src) return;
    const p = audioApi().play({ src, volume: game.settings.get(ID, "sfxVolume"), loop: false }, false);
    p?.catch?.(() => {});
  } catch { /* audio is best-effort */ }
}

async function startMusic() {
  stopMusic();
  const token = ++musicToken;
  try {
    const src = game.settings.get(ID, "musicBoard");
    if (!src || game.settings.get(ID, "musicMuted")) return;
    const snd = await audioApi().play({ src, volume: game.settings.get(ID, "musicVolume"), loop: true }, false);
    if (token !== musicToken || !board?.rendered) { snd?.stop?.(); return; }
    boardMusic = snd;
  } catch { /* missing or blocked audio file */ }
}

function stopMusic() {
  musicToken++;
  const s = boardMusic;
  boardMusic = null;
  if (!s) return;
  try {
    if (typeof s.fade === "function") s.fade(0, { duration: 600 }).then(() => s.stop(), () => s.stop());
    else s.stop();
  } catch { try { s.stop(); } catch { /* already stopped */ } }
}

function musicSettingChanged() {
  if (board?.rendered) startMusic();
  refresh();
}

/* Plays the progress sound when one of my active quests gains an objective count or a step. */
function snapProgress() {
  const m = new Map();
  for (const { q, st } of myQuests()) {
    if (st.status !== "active") continue;
    m.set(q.id, { s: stageIndex(q, st), n: [].concat(st.progress ?? []).reduce((a, b) => a + (Number(b) || 0), 0) });
  }
  return m;
}
function watchProgress() {
  const next = snapProgress();
  if (progSnap) {
    for (const [id, n] of next) {
      const o = progSnap.get(id);
      if (o && (n.s > o.s || (n.s === o.s && n.n > o.n))) { playSfx("progress"); break; }
    }
  }
  progSnap = next;
}

/* ---------- Quest board window ---------- */
class QuestBoard extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "quest-board", classes: ["quest-board"],
    window: { title: "Quest Board", resizable: true },
    position: { width: 1000, height: 640 },
    actions: {
      filter(e, t) { this.tab = t.dataset.filter; this.render(); },
      select(e, t) { this.sel = t.dataset.id; this.render(); },
      mute() { game.settings.set(ID, "musicMuted", !game.settings.get(ID, "musicMuted")); },
      accept() { route({ action: "accept", id: this.sel }); },
      cancel() { route({ action: "cancel", id: this.sel }); },
      report() { route({ action: "report", id: this.sel }); },
      prog(e, t) { route({ action: "prog", id: this.sel, bucket: t.dataset.bucket, obj: Number(t.dataset.obj), delta: Number(t.dataset.delta) }); },
      loot() { openLoot(); },
      log() { openLog(); },
      async add() { await editQuest(); },
      async edit() { await editQuest(Q().find(q => q.id === this.sel)); },
      async del() {
        const q = Q().find(x => x.id === this.sel);
        if (!q) return;
        const ok = await DialogV2.confirm({ window: { title: "Delete posting" }, content: `<p>Delete “${esc(q.title)}”?</p>` });
        if (!ok) return;
        this.sel = null;
        await game.settings.set(ID, "quests", Q().filter(x => x.id !== q.id));
        await purgeQuest(q.id);
      },
      async failquest(e, t) {
        const q = Q().find(x => x.id === this.sel);
        if (!q) return;
        const p = q.penalty ?? {};
        const has = p.gold || (p.items ?? []).length || p.text;
        const ok = await DialogV2.confirm({ window: { title: "Fail quest" }, content: `<p>Fail “${esc(q.title)}” for ${t.dataset.bucket === "party" ? "the whole party" : esc(game.users.get(t.dataset.bucket)?.name ?? "this player")}?${has ? " Its penalty will be applied." : ""} Abandoning has no penalty; this does.</p>` });
        if (ok) route({ action: "fail", id: q.id, bucket: t.dataset.bucket });
      },
      async reveal() {
        const q = Q().find(x => x.id === this.sel);
        if (!q) return;
        await game.settings.set(ID, "quests", Q().map(x => (x.id === q.id ? { ...x, revealed: true } : x)));
        sendBanner("all", "Secret quest unlocked!", q.title, q.id);
      },
      async revealObj(e, t) {
        const quests = foundry.utils.deepClone(Q());
        const q = quests.find(x => x.id === this.sel);
        const o = q?.stages?.[Number(t.dataset.s)]?.objectives?.[Number(t.dataset.o)];
        if (!o) return;
        o.revealed = true;
        await game.settings.set(ID, "quests", quests);
        await resyncJournals(q);
        sendBanner("all", "Secret objective unlocked!", o.text, q.id);
      }
    }
  };
  static PARTS = { main: { template: `modules/${ID}/templates/board.hbs` } };
  tab = "all";
  sel = null;

  async _prepareContext() {
    const state = S(), uid = game.user.id, isGM = game.user.isGM;
    const max = game.settings.get(ID, "slots");
    const used = activeCount(state.party) + activeCount(state[uid]);
    const stOf = q => state[bucketOf(q, uid)]?.[q.id];
    const tabOk = q => this.tab === "all"
      || (this.tab === "guild" ? scopeOf(q) === "party" : this.tab === "personal" ? scopeOf(q) === "personal" : !(q.source === "item" || (q.startItems ?? []).length));
    const cards = Q().filter(q => isGM || (visibleTo(q) && onBoard(q))).filter(tabOk).map(q => {
      const st = stOf(q), scope = scopeOf(q), n = stagesOf(q).length;
      return {
        ...q, scope, party: scope === "party", scopeLabel: scope === "party" ? "Guild" : "Personal",
        type: qualOf(q), label: TYPES[qualOf(q)], items: fmtItems(q.items), fromItem: q.source === "item" || !!(q.startItems ?? []).length,
        secret: secretOf(q), locked: secretOf(q) && !q.revealed,
        active: st?.status === "active", done: st?.status === "done", failed: st?.status === "failed", fromNpc: q.source === "npc",
        chainTag: n > 1 && st?.status === "active" ? `Step ${stageIndex(q, st) + 1}/${n}` : ""
      };
    });
    const sel = cards.find(c => c.id === this.sel) ?? cards[0];
    if (sel) { sel.sel = true; this.sel = sel.id; }
    return {
      hasMusic: !!game.settings.get(ID, "musicBoard"), muted: !!game.settings.get(ID, "musicMuted"),
      isGM, cards, sel, used, max, currency: game.settings.get(ID, "currency"), lootCount: LOOT().length,
      slots: Array.from({ length: max }, (_, i) => ({ on: i < used })),
      tabs: [["all", "All"], ["request", "Requests"], ["guild", "Guild Quests"], ["personal", "Personal Quests"]]
        .map(([id, label]) => ({ id, label, on: this.tab === id })),
      ...(sel ? detailOf(sel, state, stOf(sel), isGM) : {})
    };
  }

  _onClose(options) {
    super._onClose?.(options);
    stopMusic();
  }

  _onRender(context, options) {
    if (options?.isFirstRender) startMusic();
    if (!fx) return;
    this.element.querySelector(`.qb-card[data-id="${fx.id}"]`)?.classList.add(`fx-${fx.type}`);
    const toast = this.element.querySelector(".qb-toast");
    toast.textContent = fx.text;
    toast.classList.add("show");
    setTimeout(() => toast?.classList.remove("show"), 2600);
    fx = null;
  }
}

/* ---------- Party loot window ---------- */
class LootWindow extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "quest-board-loot", classes: ["quest-board", "qb-loot"],
    window: { title: "Party Loot", resizable: true },
    position: { width: 560, height: "auto" },
    actions: {
      give(e, t) {
        const row = t.closest("[data-id]");
        const actor = row.querySelector("select").value;
        if (!actor) return ui.notifications.warn("Choose who receives this item first.");
        route({ action: "give", loot: row.dataset.id, actor });
      },
      discard(e, t) { route({ action: "discard", loot: t.closest("[data-id]").dataset.id }); }
    }
  };
  static PARTS = { main: { template: `modules/${ID}/templates/loot.hbs` } };
  choice = {};

  async _prepareContext() {
    const members = partyActors();
    return {
      isGM: game.user.isGM, noMembers: !members.length,
      rows: LOOT().map(l => ({
        ...l, x: l.qty > 1 ? `×${l.qty}` : "",
        opts: members.map(a => ({ id: a.id, name: a.name, sel: this.choice[l.id] === a.id }))
      }))
    };
  }

  _onRender() {
    for (const s of this.element.querySelectorAll("select")) {
      s.addEventListener("change", () => { this.choice[s.closest("[data-id]").dataset.id] = s.value; });
    }
  }
}

function openBoard(qid) {
  board ??= new QuestBoard();
  if (typeof qid === "string") { board.sel = qid; board.tab = "all"; }
  board.render({ force: true });
}
function openLoot() { lootWin ??= new LootWindow(); lootWin.render({ force: true }); }
function openLog(qid) {
  logWin ??= new QuestLog();
  if (typeof qid === "string") logWin.sel = qid;
  logWin.render({ force: true });
}
function styleOf() {
  let s = "gold";
  try { s = game.settings.get(ID, "uiStyle"); if (s === "default") s = game.settings.get(ID, "defaultStyle"); } catch { /* not registered yet */ }
  return s === "parchment" ? "parchment" : "gold";
}
function applyTheme() { document.body.classList.toggle("qb-parchment", styleOf() === "parchment"); }

function refresh() {
  applyTheme();
  if (trackerReady) watchProgress();
  if (board?.rendered) board.render();
  if (lootWin?.rendered) lootWin.render();
  if (logWin?.rendered) logWin.render();
  if (offerWin?.rendered) offerWin.render();
  renderTracker();
}

/* ---------- Accepted quests for the current user ---------- */
function myQuests() {
  const state = S(), uid = game.user.id;
  return Q().map(q => ({ q, st: state[bucketOf(q, uid)]?.[q.id] })).filter(({ st }) => st);
}

/* ---------- Quest log window ---------- */
class QuestLog extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "quest-log", classes: ["quest-board", "qb-log"],
    window: { title: "Quest Log", resizable: true },
    position: { width: 900, height: 600 },
    actions: {
      select(e, t) { this.sel = t.dataset.id; this.render(); },
      report() { route({ action: "report", id: this.sel }); },
      board() { openBoard(); },
      async abandon() {
        const q = Q().find(x => x.id === this.sel);
        if (!q) return;
        const shared = scopeOf(q) === "party" ? " This is a guild quest, so it is abandoned for the whole party." : "";
        const ok = await DialogV2.confirm({ window: { title: "Abandon quest" }, content: `<p>Abandon “${esc(q.title)}”? Progress will be lost.${shared}</p>` });
        if (ok) route({ action: "cancel", id: q.id });
      }
    }
  };
  static PARTS = { main: { template: `modules/${ID}/templates/log.hbs` } };
  sel = null;
  showDone = false;

  async _prepareContext() {
    const state = S();
    const untracked = new Set(game.settings.get(ID, "untracked"));
    const mine = myQuests().filter(({ st }) => this.showDone || st.status === "active");
    const pick = mine.find(({ q }) => q.id === this.sel) ?? mine[0];
    if (pick) this.sel = pick.q.id;
    const rows = mine.map(({ q, st }) => {
      const n = stagesOf(q).length, active = st.status === "active";
      return {
        id: q.id, title: q.title, type: qualOf(q), sel: q.id === pick?.q.id, done: !active, failed: st.status === "failed", tracked: !untracked.has(q.id),
        ready: active && stageMet(q, st), chainTag: n > 1 && active ? `${stageIndex(q, st) + 1}/${n}` : ""
      };
    });
    let sel = null, detail = {};
    if (pick) {
      const { q, st } = pick;
      sel = {
        ...q, type: qualOf(q), label: TYPES[qualOf(q)], scopeLabel: scopeOf(q) === "party" ? "Guild" : "Personal", items: fmtItems(q.items),
        active: st.status === "active", done: st.status === "done", failed: st.status === "failed"
      };
      detail = detailOf(q, state, st, false);
    }
    return { rows, sel, showDone: this.showDone, currency: game.settings.get(ID, "currency"), ...detail };
  }

  _onRender() {
    this.element.querySelector(".qb-showall input")?.addEventListener("change", e => { this.showDone = e.target.checked; this.render(); });
    for (const cb of this.element.querySelectorAll(".qb-logrow input")) {
      cb.addEventListener("click", e => e.stopPropagation());
      cb.addEventListener("change", e => {
        const id = cb.closest("[data-id]").dataset.id;
        const set = new Set(game.settings.get(ID, "untracked"));
        if (e.target.checked) set.delete(id); else set.add(id);
        game.settings.set(ID, "untracked", [...set]);
      });
    }
  }
}

/* ---------- Quest tracker: an always-on panel for accepted quests ---------- */
let trackerEl = null;
let trackerReady = false;
let trackerRendered = false;
const trackerSigs = new Map();

function trackerData() {
  const untracked = new Set(game.settings.get(ID, "untracked"));
  const groups = new Map();
  for (const { q, st } of myQuests()) {
    if (st.status !== "active" || untracked.has(q.id)) continue;
    const stages = stagesOf(q), si = stageIndex(q, st);
    const objs = stages[si].objectives.map((o, i) => ({ o, i })).filter(({ o }) => isOpen(o)).map(({ o, i }) => {
      const req = needed(o), value = Math.min(getProg(st, i), req);
      return { text: o.text, value, required: req, done: value >= req };
    });
    const name = String(q.location ?? "").trim() || "Quests";
    if (!groups.has(name)) groups.set(name, []);
    groups.get(name).push({
      id: q.id, title: q.title, type: qualOf(q), tag: stages.length > 1 ? `${si + 1}/${stages.length}` : "",
      ready: stageMet(q, st), image: q.image || "", objs, sig: `${si}|${[].concat(st.progress ?? []).join(",")}|${objs.length}`
    });
  }
  return [...groups].map(([name, quests]) => ({ name, quests }));
}

function trackerHTML(groups, collapsed) {
  const total = groups.reduce((n, g) => n + g.quests.length, 0);
  const head = `<header class="qb-tr-head"><i class="qb-tr-dia"></i><b>Quests</b><span class="n">${total}</span>
    <button type="button" data-act="log" title="Open quest log"><i class="fa-solid fa-book-open"></i></button>
    <button type="button" data-act="fold" title="${collapsed ? "Expand" : "Collapse"}"><i class="fa-solid fa-chevron-${collapsed ? "down" : "up"}"></i></button></header>`;
  if (collapsed) return head;
  const quest = q => `<div class="qb-tr-quest ${esc(q.type)} ${q.ready ? "ready" : ""}" data-id="${esc(q.id)}" data-sig="${esc(q.sig)}">
      <b>${q.image ? `<img class="qb-tr-img" src="${esc(q.image)}" alt="">` : `<i class="dia"></i>`}${esc(q.title)}${q.tag ? ` <small>${esc(q.tag)}</small>` : ""}</b>
      <ul>${q.objs.map(o => `<li class="${o.done ? "done" : ""}">${esc(o.text)}${o.required > 1 ? ` <span>${o.value}/${o.required}</span>` : ""}</li>`).join("")}</ul></div>`;
  return head + `<div class="qb-tr-body">${groups.map(g => `<section class="qb-tr-group"><h5><span class="n">[${g.quests.length}]</span> ${esc(g.name)}</h5>${g.quests.map(quest).join("")}</section>`).join("")}</div>`;
}

function placeTracker() {
  const p = game.settings.get(ID, "trackerPos");
  const x = Number.isFinite(p?.x) ? p.x : 96, y = Number.isFinite(p?.y) ? p.y : 120;
  trackerEl.style.left = `${Math.min(Math.max(0, x), Math.max(0, window.innerWidth - 80))}px`;
  trackerEl.style.top = `${Math.min(Math.max(0, y), Math.max(0, window.innerHeight - 40))}px`;
}

function buildTracker() {
  trackerEl = document.createElement("aside");
  trackerEl.id = "qb-tracker";
  trackerEl.className = "qb-tracker";
  document.body.append(trackerEl);
  trackerEl.addEventListener("click", e => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (act === "log") return openLog();
    if (act === "fold") return game.settings.set(ID, "trackerCollapsed", !game.settings.get(ID, "trackerCollapsed"));
    const id = e.target.closest("[data-id]")?.dataset.id;
    if (id) openLog(id);
  });
  trackerEl.addEventListener("pointerdown", e => {
    if (!e.target.closest(".qb-tr-head") || e.target.closest("button")) return;
    const r = trackerEl.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
    const move = ev => { trackerEl.style.left = `${ev.clientX - dx}px`; trackerEl.style.top = `${ev.clientY - dy}px`; };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      const b = trackerEl.getBoundingClientRect();
      game.settings.set(ID, "trackerPos", { x: Math.round(b.left), y: Math.round(b.top) });
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    e.preventDefault();
  });
}

function renderTracker() {
  if (!trackerReady) return;
  const groups = game.settings.get(ID, "trackerShow") ? trackerData() : [];
  if (!groups.length) { if (trackerEl) trackerEl.hidden = true; return; }
  if (!trackerEl) buildTracker();
  const collapsed = game.settings.get(ID, "trackerCollapsed");
  trackerEl.hidden = false;
  trackerEl.classList.toggle("collapsed", collapsed);
  trackerEl.innerHTML = trackerHTML(groups, collapsed);
  const seen = new Set();
  for (const el of trackerEl.querySelectorAll(".qb-tr-quest")) {
    const id = el.dataset.id, sig = el.dataset.sig;
    seen.add(id);
    if (trackerRendered && trackerSigs.get(id) !== sig) el.classList.add("flash");
    trackerSigs.set(id, sig);
  }
  if (!collapsed) for (const id of [...trackerSigs.keys()]) if (!seen.has(id)) trackerSigs.delete(id);
  trackerRendered = true;
  placeTracker();
}

/* ---------- On-screen banner ("Secret quest unlocked!") ---------- */
function showBanner({ title, sub, qid, view, tone }) {
  document.querySelector(".qb-banner")?.remove();
  const el = document.createElement("div");
  el.className = tone === "fail" ? "qb-banner fail" : "qb-banner";
  el.innerHTML = `<div class="qb-banner-in"><div class="qb-banner-gem">◈</div><h2>${esc(title)}</h2>${sub ? `<p>${esc(sub)}</p>` : ""}</div>`;
  el.querySelector(".qb-banner-in").addEventListener("click", () => { el.remove(); if (view === "log") openLog(qid); else openBoard(qid); });
  document.body.append(el);
  setTimeout(() => el.classList.add("out"), 4200);
  setTimeout(() => el.remove(), 5000);
}

function sendBanner(target, title, sub, qid, view = "board", tone = "") {
  const m = { action: "banner", user: target, title, sub, qid, view, tone };
  game.socket.emit(CH, m);
  if (target === "all" || target === game.user.id) showBanner(m);
}

/* ---------- GM edit dialog: steps, objectives (manual or automatic), item drop zones ---------- */
const MODES = { manual: "Manual", token: "Kill a token", actor: "Kill an actor", item: "Hold an item" };
const modeOf = o => (!o.track ? "manual" : o.track.kind === "item" ? "item" : o.track.mode);

async function editQuest(q = {}) {
  const v = { scope: "party", gold: 0, ...q };
  v.type = qualOf(q);
  v.source = q.source ?? ((q.startItems ?? []).length ? "item" : "board");
  v.image = q.image ?? "";
  v.penaltyGold = q.penalty?.gold ?? 0;
  v.penaltyText = q.penalty?.text ?? "";
  const penItems = foundry.utils.deepClone(q.penalty?.items ?? []);
  const fails = foundry.utils.deepClone(q.failWhen ?? []);
  let giver = q.giverActor ? foundry.utils.deepClone(q.giverActor) : null;
  const items = foundry.utils.deepClone(q.items ?? []);
  const startItems = foundry.utils.deepClone(q.startItems ?? []);
  const stages = q.id ? foundry.utils.deepClone(stagesOf(q)) : [blankStage()];
  const f = (n, l, t = "text") => `<div class="form-group"><label>${l}</label><input type="${t}" name="${n}" value="${esc(v[n])}"></div>`;
  const opts = (map, cur) => Object.entries(map).map(([k, l]) => `<option value="${k}" ${cur === k ? "selected" : ""}>${l}</option>`).join("");
  const content = `<div class="qb-edit">
    ${f("title", "Title")}
    <div class="form-group"><label>Quality</label><select name="type">${opts(TYPES, v.type)}</select></div>
    <div class="form-group"><label>Quest comes from</label><select name="source">${opts({ board: "The quest board (players pick it up)", item: "An item (found in the world)", npc: "A quest giver (an NPC offers it)" }, v.source)}</select></div>
    <div class="qb-itemsrc" ${v.source === "item" ? "" : "hidden"}>
      <div class="form-group stacked"><label>Item that starts this quest</label>
        <p class="hint">When a party character receives one of these items, the quest is revealed with the unlock banner. Item quests stay secret until then.</p>
        <div class="qb-drop" data-zone="start"></div></div>
      <div class="form-group"><label>Accept on pickup</label><input type="checkbox" name="autoAccept" ${v.autoAccept ? "checked" : ""}><p class="hint">Also accept the quest as soon as the item is found.</p></div>
    </div>
    <div class="qb-npcsrc" ${v.source === "npc" ? "" : "hidden"}>
      <div class="form-group stacked"><label>Quest giver</label>
        <p class="hint">Drop the NPC's actor here, or select its token and use the button. You offer the quest from the NPC's token HUD; players can target the NPC and use the Quest giver tool.</p>
        <div class="qb-giverbox"></div></div>
      <div class="form-group"><label>Also post on the board</label><input type="checkbox" name="alsoBoard" ${v.alsoBoard ? "checked" : ""}><p class="hint">NPC quests are normally kept off the board.</p></div>
      <div class="form-group"><label>Turn in at the giver</label><input type="checkbox" name="reportToGiver" ${v.reportToGiver ? "checked" : ""}><p class="hint">The final step can only be completed by returning to this NPC.</p></div>
    </div>
    <div class="form-group"><label>Picture</label><div class="qb-pic"><input type="text" name="image" value="${esc(v.image)}" placeholder="Optional image for the posting"><button type="button" data-act="pickimg" title="Browse files"><i class="fa-solid fa-folder-open"></i></button></div></div>
    <div class="form-group"><label>Quest log</label><select name="scope">${opts({ party: "Guild quest (shared by the whole party)", personal: "Personal quest (each player tracks their own)" }, scopeOf(v))}</select></div>
    ${f("giver", "Client")}${f("location", "Location")}${f("kind", "Kind (Hunt, Delivery…)")}
    <div class="form-group"><label>Description</label><textarea name="desc" rows="4">${esc(v.desc)}</textarea></div>
    <div class="form-group stacked"><label>Steps and objectives</label>
      <p class="hint">One step is a normal quest. Add more steps to make a chain. Each objective is either Manual (you adjust it on the board) or automatic: it ticks off when a linked monster is defeated, or follows how many of a linked item the party is holding.</p>
      <div class="qb-stages"></div></div>
    <div class="form-group stacked"><label>Fail conditions</label>
      <p class="hint">Optional. A condition with a linked token or actor fails the quest automatically when that creature is defeated. A note-only condition is shown to players and you fail the quest yourself from the board.</p>
      <div class="qb-fails"></div></div>
    ${f("penaltyGold", "Penalty: currency lost", "number")}
    <div class="form-group stacked"><label>Penalty: items lost</label><div class="qb-drop" data-zone="penalty"></div></div>
    ${f("penaltyText", "Penalty: other (text only)")}
    <div class="form-group"><label>Keep penalty secret</label><input type="checkbox" name="penaltyHidden" ${v.penaltyHidden ? "checked" : ""}><p class="hint">Players are not told what failing costs. Penalties only apply when the quest is failed, never when it is abandoned.</p></div>
    <div class="form-group"><label>Can retry after failing</label><input type="checkbox" name="retry" ${v.retry ? "checked" : ""}><p class="hint">The quest becomes available again after a failure. Otherwise it stays failed.</p></div>
    ${f("gold", "Currency reward", "number")}
    <div class="form-group"><label>Item rewards</label><div class="qb-drop" data-zone="rewards"></div></div>
    ${f("item", "Other reward (text only)")}
    <div class="form-group"><label>One-time</label><input type="checkbox" name="once" ${v.once ? "checked" : ""}></div>
    <div class="form-group qb-secretrow" ${v.source === "item" ? "hidden" : ""}><label>Secret quest</label><input type="checkbox" name="secret" ${secretOf(v) ? "checked" : ""}><p class="hint">Hidden from players until you press Reveal on the board.</p></div>
  </div>`;

  const render = (event, dialog) => {
    const root = dialog.element;
    if (root.dataset.qbBound) return;
    root.dataset.qbBound = "1";
    root.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.tagName === "INPUT") e.preventDefault(); });
    const srcSel = root.querySelector('select[name="source"]');
    srcSel.addEventListener("change", () => {
      const item = srcSel.value === "item";
      root.querySelector(".qb-itemsrc").hidden = !item;
      root.querySelector(".qb-npcsrc").hidden = srcSel.value !== "npc";
      root.querySelector(".qb-secretrow").hidden = item;
    });
    root.querySelector('[data-act="pickimg"]').addEventListener("click", () => {
      const FP = foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
      if (!FP) return ui.notifications.warn("The file browser is not available. Type the image path instead.");
      const input = root.querySelector('input[name="image"]');
      new FP({ type: "image", current: input.value, callback: path => { input.value = path; } }).render(true);
    });
    const readDrop = e => { try { return JSON.parse(e.dataTransfer.getData("text/plain")); } catch { return null; } };

    /* quest giver actor */
    const gbox = root.querySelector(".qb-giverbox");
    const drawGiver = () => {
      gbox.innerHTML = (giver
        ? `<span class="qb-linked">${giver.img ? `<img src="${esc(giver.img)}" alt="">` : ""}${esc(giver.name)}<button type="button" data-act="ungiver" title="Clear"><i class="fa-solid fa-xmark"></i></button></span>`
        : `<div class="qb-linkdrop">Drop an actor here</div>`) + `<button type="button" data-act="giverfromtoken">Use selected token's actor</button>`;
    };
    gbox.addEventListener("click", e => {
      const a = e.target.closest("[data-act]")?.dataset.act;
      if (a === "ungiver") giver = null;
      else if (a === "giverfromtoken") {
        const t = canvas.tokens?.controlled?.[0];
        if (!t?.actor) return ui.notifications.warn("Select a token on the canvas first.");
        giver = actorLink(t.actor);
      } else return;
      drawGiver();
    });
    gbox.addEventListener("dragover", e => e.preventDefault());
    gbox.addEventListener("drop", async e => {
      e.preventDefault();
      const d = readDrop(e);
      if (d?.type !== "Actor" || !d.uuid) return ui.notifications.warn("Drop an Actor here.");
      const doc = await fromUuid(d.uuid);
      if (!doc) return ui.notifications.warn("That actor could not be found.");
      giver = actorLink(doc);
      drawGiver();
    });
    drawGiver();

    /* fail conditions */
    const fz = root.querySelector(".qb-fails");
    const FMODES = { note: "Note only", token: "Token defeated", actor: "Actor defeated" };
    const fmode = f => (f.track ? f.track.mode : "note");
    const chipHTML = t => (t?.uuid ? `<span class="qb-linked">${t.img ? `<img src="${esc(t.img)}" alt="">` : ""}${esc(t.name)}<button type="button" data-act="funlink" title="Clear link"><i class="fa-solid fa-xmark"></i></button></span>` : "");
    const drawFails = () => {
      fz.innerHTML = fails.map((f, i) => {
        const m = fmode(f);
        const link = m === "token" ? `${chipHTML(f.track)}<button type="button" data-act="ftoken">Use selected token</button>`
          : m === "actor" ? `${chipHTML(f.track)}<div class="qb-linkdrop" data-accept="Actor">Drop an actor here</div><button type="button" data-act="ftokenactor">Use selected token's actor</button>` : "";
        return `<div class="qb-fail" data-i="${i}"><div class="qb-orow"><input data-f="text" value="${esc(f.text)}" placeholder="e.g. The merchant is killed">
          <select data-f="mode">${opts(FMODES, m)}</select><button type="button" data-act="frm" title="Remove"><i class="fa-solid fa-xmark"></i></button></div>${link ? `<div class="qb-link">${link}</div>` : ""}</div>`;
      }).join("") + `<button type="button" data-act="fadd"><i class="fa-solid fa-plus"></i> Fail condition</button>`;
    };
    const onFail = e => {
      const fld = e.target.dataset.f;
      if (!fld) return;
      const f = fails[Number(e.target.closest("[data-i]").dataset.i)];
      if (fld === "text") { f.text = e.target.value; return; }
      if (fmode(f) !== e.target.value) { f.track = e.target.value === "note" ? undefined : { kind: "kill", mode: e.target.value }; drawFails(); }
    };
    fz.addEventListener("input", onFail);
    fz.addEventListener("change", onFail);
    fz.addEventListener("click", e => {
      const b = e.target.closest("[data-act]");
      if (!b) return;
      const row = b.closest("[data-i]"), f = row ? fails[Number(row.dataset.i)] : null;
      const tok = () => canvas.tokens?.controlled?.[0];
      switch (b.dataset.act) {
        case "fadd": fails.push({ text: "" }); break;
        case "frm": fails.splice(Number(row.dataset.i), 1); break;
        case "funlink": f.track = { kind: "kill", mode: f.track.mode }; break;
        case "ftoken": {
          const t = tok();
          if (!t) { ui.notifications.warn("Select a token on the canvas first."); break; }
          f.track = { kind: "kill", mode: "token", uuid: t.document.uuid, name: t.name, img: t.document.texture?.src };
          if (!String(f.text ?? "").trim()) f.text = `${t.name} is defeated`;
          break;
        }
        case "ftokenactor": {
          const t = tok(), base = t?.actor?.token?.baseActor ?? t?.actor;
          if (!base) { ui.notifications.warn("Select a token on the canvas first."); break; }
          f.track = { kind: "kill", mode: "actor", uuid: base.uuid, name: base.name, img: base.img };
          if (!String(f.text ?? "").trim()) f.text = `${base.name} is defeated`;
          break;
        }
      }
      drawFails();
    });
    fz.addEventListener("dragover", e => { const z = e.target.closest(".qb-linkdrop"); if (z) { e.preventDefault(); z.classList.add("over"); } });
    fz.addEventListener("dragleave", e => e.target.closest?.(".qb-linkdrop")?.classList.remove("over"));
    fz.addEventListener("drop", async e => {
      const z = e.target.closest(".qb-linkdrop");
      if (!z) return;
      e.preventDefault();
      const d = readDrop(e);
      if (d?.type !== "Actor" || !d.uuid) return ui.notifications.warn("Drop an Actor here.");
      const doc = await fromUuid(d.uuid);
      if (!doc) return ui.notifications.warn("That could not be found.");
      const base = doc.token?.baseActor ?? doc, f = fails[Number(z.closest("[data-i]").dataset.i)];
      f.track = { kind: "kill", mode: "actor", uuid: base.uuid, name: base.name, img: base.img };
      if (!String(f.text ?? "").trim()) f.text = `${base.name} is defeated`;
      drawFails();
    });
    drawFails();

    /* steps and objectives */
    const sz = root.querySelector(".qb-stages");
    const linkHTML = o => {
      const t = o.track, mode = modeOf(o);
      const chip = t.uuid ? `<span class="qb-linked">${t.img ? `<img src="${esc(t.img)}" alt="">` : ""}${esc(t.name)}<button type="button" data-act="unlink" title="Clear link"><i class="fa-solid fa-xmark"></i></button></span>` : "";
      if (mode === "token") return `${chip}<button type="button" data-act="usetoken">Use selected token</button>${t.uuid ? "" : `<span class="hint">Select the monster's token on the canvas first.</span>`}`;
      if (mode === "actor") return `${chip}<div class="qb-linkdrop" data-accept="Actor">Drop an actor here</div><button type="button" data-act="usetokenactor">Use selected token's actor</button>`;
      return `${chip}<div class="qb-linkdrop" data-accept="Item">Drop an item here</div>`;
    };
    const drawStages = () => {
      sz.innerHTML = stages.map((s, si) => `<div class="qb-stage" data-s="${si}">
        <div class="qb-srow"><b>Step ${si + 1}</b><input data-f="name" value="${esc(s.name)}" placeholder="Step title, e.g. Speak to Earl James">
          <button type="button" data-act="up" ${si === 0 ? "disabled" : ""} title="Move up"><i class="fa-solid fa-arrow-up"></i></button>
          <button type="button" data-act="down" ${si === stages.length - 1 ? "disabled" : ""} title="Move down"><i class="fa-solid fa-arrow-down"></i></button>
          <button type="button" data-act="rmstage" ${stages.length === 1 ? "disabled" : ""} title="Remove step"><i class="fa-solid fa-trash"></i></button></div>
        <textarea data-f="desc" rows="2" placeholder="What the party learns or must do in this step (optional)">${esc(s.desc)}</textarea>
        ${s.objectives.map((o, oi) => `<div class="qb-obj" data-o="${oi}"><div class="qb-orow">
          <input data-f="text" value="${esc(o.text)}" placeholder="Objective, e.g. Defeat the witch">
          <input data-f="required" type="number" min="1" value="${needed(o)}" title="Count needed">
          <select data-f="mode" title="How this objective is completed">${opts(MODES, modeOf(o))}</select>
          <label title="Hidden from players until you reveal it"><input data-f="secret" type="checkbox" ${o.secret ? "checked" : ""}> Secret</label>
          <button type="button" data-act="rmobj" ${s.objectives.length === 1 ? "disabled" : ""} title="Remove objective"><i class="fa-solid fa-xmark"></i></button></div>
          ${o.track ? `<div class="qb-link">${linkHTML(o)}</div>` : ""}</div>`).join("")}
        <button type="button" data-act="addobj"><i class="fa-solid fa-plus"></i> Objective</button></div>`).join("")
        + `<button type="button" data-act="addstage"><i class="fa-solid fa-plus"></i> Add step</button>`;
    };
    const linkTo = (o, track) => {
      o.track = track;
      if (!String(o.text ?? "").trim()) o.text = `${track.kind === "item" ? "Collect" : "Defeat"} ${track.name}`;
    };
    const onEdit = e => {
      const t = e.target, fld = t.dataset.f;
      if (!fld) return;
      const si = Number(t.closest("[data-s]").dataset.s);
      const orow = t.closest("[data-o]");
      if (!orow) { stages[si][fld] = t.value; return; }
      const o = stages[si].objectives[Number(orow.dataset.o)];
      if (fld === "mode") {
        if (modeOf(o) !== t.value) {
          o.track = t.value === "manual" ? undefined : t.value === "item" ? { kind: "item" } : { kind: "kill", mode: t.value };
          drawStages();
        }
        return;
      }
      o[fld] = fld === "secret" ? t.checked : fld === "required" ? needed({ required: t.value }) : t.value;
    };
    sz.addEventListener("input", onEdit);
    sz.addEventListener("change", onEdit);
    sz.addEventListener("click", e => {
      const b = e.target.closest("[data-act]");
      if (!b) return;
      const sEl = b.closest("[data-s]"), si = sEl ? Number(sEl.dataset.s) : -1;
      const oEl = b.closest("[data-o]"), o = oEl ? stages[si].objectives[Number(oEl.dataset.o)] : null;
      const tok = () => canvas.tokens?.controlled?.[0];
      switch (b.dataset.act) {
        case "addstage": stages.push(blankStage()); break;
        case "rmstage": if (stages.length > 1) stages.splice(si, 1); break;
        case "up": if (si > 0) [stages[si - 1], stages[si]] = [stages[si], stages[si - 1]]; break;
        case "down": if (si < stages.length - 1) [stages[si + 1], stages[si]] = [stages[si], stages[si + 1]]; break;
        case "addobj": stages[si].objectives.push(blankObj()); break;
        case "rmobj": if (stages[si].objectives.length > 1) stages[si].objectives.splice(Number(oEl.dataset.o), 1); break;
        case "unlink": o.track = { kind: o.track.kind, mode: o.track.mode }; break;
        case "usetoken": {
          const t = tok();
          if (!t) { ui.notifications.warn("Select a token on the canvas first."); break; }
          linkTo(o, { kind: "kill", mode: "token", uuid: t.document.uuid, name: t.name, img: t.document.texture?.src });
          break;
        }
        case "usetokenactor": {
          const t = tok(), base = t?.actor?.token?.baseActor ?? t?.actor;
          if (!base) { ui.notifications.warn("Select a token on the canvas first."); break; }
          linkTo(o, { kind: "kill", mode: "actor", uuid: base.uuid, name: base.name, img: base.img });
          break;
        }
      }
      drawStages();
    });
    sz.addEventListener("dragover", e => { const z = e.target.closest(".qb-linkdrop"); if (z) { e.preventDefault(); z.classList.add("over"); } });
    sz.addEventListener("dragleave", e => e.target.closest?.(".qb-linkdrop")?.classList.remove("over"));
    sz.addEventListener("drop", async e => {
      const z = e.target.closest(".qb-linkdrop");
      if (!z) return;
      e.preventDefault();
      z.classList.remove("over");
      const data = readDrop(e), accept = z.dataset.accept;
      if (data?.type !== accept || !data.uuid) return ui.notifications.warn(`Drop an ${accept.toLowerCase()} here.`);
      const doc = await fromUuid(data.uuid);
      if (!doc) return ui.notifications.warn("That could not be found.");
      const o = stages[Number(z.closest("[data-s]").dataset.s)].objectives[Number(z.closest("[data-o]").dataset.o)];
      if (accept === "Actor") {
        const base = doc.token?.baseActor ?? doc;
        linkTo(o, { kind: "kill", mode: "actor", uuid: base.uuid, name: base.name, img: base.img });
      } else {
        await stampSource(doc);
        linkTo(o, { kind: "item", uuid: doc.uuid, name: doc.name, type: doc.type, img: doc.img });
      }
      drawStages();
    });
    drawStages();

    /* item drop zones: rewards (with quantity) and quest-starting items */
    const bindZone = (zone, list, { qty, hint, stamp }) => {
      const draw = () => {
        zone.innerHTML = list.length
          ? list.map((it, i) => `<div class="row"><img src="${esc(it.img)}" alt=""><span>${esc(it.name)}</span>${qty ? `<input type="number" min="1" value="${it.qty}" data-i="${i}">` : ""}<button type="button" data-rm="${i}"><i class="fa-solid fa-xmark"></i></button></div>`).join("")
          : `<p class="hint">${hint}</p>`;
      };
      zone.addEventListener("dragover", e => { e.preventDefault(); zone.classList.add("over"); });
      zone.addEventListener("dragleave", () => zone.classList.remove("over"));
      zone.addEventListener("drop", async e => {
        e.preventDefault();
        zone.classList.remove("over");
        const data = readDrop(e);
        if (data?.type !== "Item" || !data.uuid) return ui.notifications.warn("Drop an Item here.");
        const doc = await fromUuid(data.uuid);
        if (!doc) return ui.notifications.warn("That item could not be found.");
        if (stamp) await stampSource(doc);
        const existing = list.find(i => i.uuid === doc.uuid);
        if (existing) { if (qty) existing.qty += 1; }
        else list.push(qty ? { uuid: doc.uuid, name: doc.name, img: doc.img, qty: 1 } : { uuid: doc.uuid, name: doc.name, img: doc.img, type: doc.type });
        draw();
      });
      zone.addEventListener("change", e => {
        const i = e.target.dataset.i;
        if (i !== undefined) list[i].qty = Math.max(1, Math.floor(Number(e.target.value)) || 1);
      });
      zone.addEventListener("click", e => {
        const rm = e.target.closest("[data-rm]");
        if (!rm) return;
        list.splice(Number(rm.dataset.rm), 1);
        draw();
      });
      draw();
    };
    bindZone(root.querySelector('[data-zone="rewards"]'), items, { qty: true, hint: "Drag items here from the Items directory, a compendium or an actor sheet." });
    bindZone(root.querySelector('[data-zone="penalty"]'), penItems, { qty: true, stamp: true, hint: "Drag items the party loses if the quest is failed." });
    bindZone(root.querySelector('[data-zone="start"]'), startItems, { qty: false, stamp: true, hint: "Drag the item that starts this quest here." });
  };

  const data = await DialogV2.prompt({
    window: { title: q.id ? "Edit posting" : "New posting" }, position: { width: 700 },
    content, render, rejectClose: false,
    ok: { label: "Save", callback: (e, b) => new foundry.applications.ux.FormDataExtended(b.form).object }
  });
  if (!data) return;
  data.title = String(data.title ?? "").trim() || "Untitled posting";
  data.gold = Math.max(0, Number(data.gold) || 0);
  data.items = items;
  const fromItem = data.source === "item";
  const fromNpc = data.source === "npc";
  data.source = fromItem ? "item" : fromNpc ? "npc" : "board";
  data.giverActor = fromNpc ? giver : null;
  data.alsoBoard = fromNpc && !!data.alsoBoard;
  data.reportToGiver = fromNpc && !!data.reportToGiver;
  if (fromNpc && giver && !String(data.giver ?? "").trim()) data.giver = giver.name;
  if (fromNpc && !giver) ui.notifications.warn("This quest comes from a quest giver, but no actor is set yet. Nobody can offer it until you add one.");
  data.retry = !!data.retry;
  data.penaltyHidden = !!data.penaltyHidden;
  data.penalty = { gold: Math.max(0, Number(data.penaltyGold) || 0), items: penItems, text: String(data.penaltyText ?? "").trim() };
  delete data.penaltyGold;
  delete data.penaltyText;
  data.failWhen = fails.map(f => ({ ...f, text: String(f.text ?? "").trim() })).filter(f => f.text).map(f => { if (!f.track?.uuid) delete f.track; return f; });
  data.image = String(data.image ?? "").trim();
  data.startItems = fromItem ? startItems : [];
  data.autoAccept = fromItem && !!data.autoAccept;
  if (fromItem) data.secret = true;
  data.stages = stages.map(s => {
    const objectives = s.objectives.map(o => {
      const c = { ...o, text: String(o.text ?? "").trim(), required: needed(o) };
      if (!c.track?.uuid) delete c.track;
      return c;
    }).filter(o => o.text);
    const name = String(s.name ?? "").trim();
    if (!objectives.length) objectives.push({ text: name || "Complete this step", required: 1 });
    return { name: name || objectives[0].text, desc: String(s.desc ?? "").trim(), objectives };
  });
  if (data.secret && !secretOf(q)) data.revealed = false;
  if (fromItem && !startItems.length) ui.notifications.warn("This quest comes from an item, but no item is set yet. Players will not find it until you add one or press Reveal.");

  const quests = Q();
  const i = quests.findIndex(x => x.id === q.id);
  const saved = i >= 0 ? { ...quests[i], ...data } : { id: foundry.utils.randomID(), ...data };
  for (const k of ["cond", "required", "hidden"]) delete saved[k];
  if (i >= 0) quests[i] = saved; else quests.push(saved);
  await game.settings.set(ID, "quests", quests);
  await resyncJournals(saved);
  enqueue(syncTracked);
}

/* ---------- Quest givers: NPCs that offer quests directly ---------- */
const onBoard = q => q.source !== "npc" || !!q.alsoBoard;
const actorLink = actor => { const base = actor.token?.baseActor ?? actor; return { uuid: base.uuid, name: base.name, img: base.img }; };
const sameGiver = (a, b) => !!a && !!b && (a.uuid === b.uuid || sameName(a.name, b.name));
const giverQuests = link => Q().filter(q => q.source === "npc" && q.giverActor && sameGiver(q.giverActor, link));

/* Quests an NPC can hand this user right now: unaccepted ones, plus accepted ones waiting to be turned in. */
function offerEntries(link, qids) {
  const state = S(), uid = game.user.id;
  const list = qids ? Q().filter(q => qids.includes(q.id)) : giverQuests(link);
  return list.filter(q => game.user.isGM || visibleTo(q))
    .map(q => ({ q, st: state[bucketOf(q, uid)]?.[q.id] }))
    .filter(({ q, st }) => !st || (st.status === "active" && (!!qids || !!q.reportToGiver)));
}

class QuestOffer extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "quest-board-offer", classes: ["quest-board", "qb-offer"],
    window: { title: "Quest giver", resizable: true },
    position: { width: 780, height: 520 },
    actions: {
      select(e, t) { this.sel = t.dataset.id; this.render(); },
      accept() { route({ action: "accept", id: this.sel }); },
      turnin() { route({ action: "report", id: this.sel, viaGiver: true }); },
      decline() { this.close(); }
    }
  };
  static PARTS = { main: { template: `modules/${ID}/templates/offer.hbs` } };
  giver = null;
  qids = null;
  sel = null;

  async _prepareContext() {
    const state = S();
    const entries = offerEntries(this.giver, this.qids);
    const pick = entries.find(({ q }) => q.id === this.sel) ?? entries[0];
    if (pick) this.sel = pick.q.id;
    const rows = entries.map(({ q, st }) => ({ id: q.id, title: q.title, type: qualOf(q), sel: q.id === pick?.q.id, tag: st ? "In progress" : "" }));
    let sel = null, detail = {};
    if (pick) {
      const { q, st } = pick;
      sel = { ...q, type: qualOf(q), label: TYPES[qualOf(q)], scopeLabel: scopeOf(q) === "party" ? "Guild" : "Personal", party: scopeOf(q) === "party", items: fmtItems(q.items), active: st?.status === "active" };
      detail = detailOf(sel, state, st, false);
    }
    return { giver: this.giver, rows, sel, currency: game.settings.get(ID, "currency"), ...detail };
  }
}

let offerWin = null;
function openOffer({ giver, qids }) {
  offerWin ??= new QuestOffer();
  offerWin.giver = giver;
  offerWin.qids = qids ?? null;
  offerWin.sel = qids?.[0] ?? null;
  offerWin.render({ force: true });
}

function sendOffer(target, giver, qids) {
  game.socket.emit(CH, { action: "offer", user: target, giver, qids });
}

/* The GM picks one of this NPC's quests and who it is offered to. */
async function gmOffer(link) {
  const list = giverQuests(link);
  if (!list.length) return ui.notifications.warn(`No quests are assigned to ${link.name}. Make one with “Quest comes from: A quest giver” and drop this actor in.`);
  const users = game.users.filter(u => !u.isGM && u.active);
  const content = `<div class="form-group"><label>Quest</label><select name="qid">${list.map(q => `<option value="${esc(q.id)}">${esc(q.title)}</option>`).join("")}</select></div>
    <div class="form-group"><label>Offer to</label><select name="to"><option value="all">The whole party</option>${users.map(u => `<option value="${esc(u.id)}">${esc(u.name)}</option>`).join("")}</select></div>`;
  const data = await DialogV2.prompt({
    window: { title: `${link.name} offers a quest` }, content, rejectClose: false,
    ok: { label: "Offer", callback: (e, b) => new foundry.applications.ux.FormDataExtended(b.form).object }
  });
  const q = data && list.find(x => x.id === data.qid);
  if (!q) return;
  if (secretOf(q) && !q.revealed) await game.settings.set(ID, "quests", Q().map(x => (x.id === q.id ? { ...x, revealed: true } : x)));
  sendOffer(data.to, link, [q.id]);
  ui.notifications.info(`Offered “${q.title}”.`);
}

function speakTo(actor) {
  if (!actor) return ui.notifications.warn("Target an NPC token first (or select one if you are the GM).");
  const link = actorLink(actor);
  if (game.user.isGM) return gmOffer(link);
  if (!offerEntries(link).length) return ui.notifications.info(`${link.name} has nothing for you right now.`);
  openOffer({ giver: link });
}

/* ---------- Failing a quest, and its penalties ---------- */
async function takeItems(actors, link, qty) {
  let left = qty;
  for (const a of actors) {
    for (const it of [...a.items]) {
      if (left <= 0) break;
      if (!linkMatches(it, link)) continue;
      const have = Math.max(0, Number(it.system?.quantity ?? 1) || 0);
      const n = Math.min(have, left);
      if (n >= have) await it.delete(); else await it.update({ "system.quantity": have - n });
      left -= n;
    }
  }
  return qty - left;
}

async function penalize(q, bucket) {
  const p = q.penalty ?? {}, lines = [];
  const cur = game.settings.get(ID, "currency");
  const rec = bucket === "party" ? partyActors() : [game.users.get(bucket)?.character].filter(Boolean);
  if (p.gold && CURRENCIES.includes(cur) && rec.length) {
    const share = Math.floor(p.gold / rec.length), rest = p.gold - share * rec.length;
    let taken = 0;
    for (const [i, a] of rec.entries()) {
      const have = Number(a.system.currency?.[cur] ?? 0) || 0, t = Math.min(have, share + (i === 0 ? rest : 0));
      if (t > 0) { await a.update({ [`system.currency.${cur}`]: have - t }); taken += t; }
    }
    lines.push(`${taken} ${cur} lost${rec.length > 1 ? ` across ${rec.length} characters` : ""}`);
  } else if (p.gold) lines.push(`${p.gold} ${cur}`);
  for (const it of p.items ?? []) {
    const n = await takeItems(rec, it, Math.max(1, Math.floor(Number(it.qty)) || 1));
    lines.push(n ? `${itemLabel({ ...it, qty: n })} lost` : `${it.name} (none to take)`);
  }
  if (p.text) lines.push(p.text);
  return lines;
}

/* Penalties apply only here, never when a quest is abandoned. */
async function failQuest(q, bucket, reason = "") {
  const state = foundry.utils.deepClone(S());
  const mine = state[bucket], cur = mine?.[q.id];
  if (cur?.status !== "active") return false;
  const failed = { ...cur, status: "failed" };
  if (q.retry) delete mine[q.id]; else mine[q.id] = failed;
  await game.settings.set(ID, "state", state);
  await syncJournal(bucket, q, q.retry ? null : failed);
  const lines = await penalize(q, bucket);
  const who = bucket === "party" ? "The party" : esc(game.users.get(bucket)?.name ?? "A player");
  await ChatMessage.create({ content: `${who} failed <em>${esc(q.title)}</em>${reason ? ` (${esc(reason)})` : ""}.${lines.length ? ` Penalty: ${lines.map(esc).join("; ")}.` : ""}` });
  const target = bucket === "party" ? "all" : bucket;
  sendFx(target, "fail", q.id, `Failed: ${q.title}`);
  sendBanner(target, "Quest failed", q.title, q.id, "log", "fail");
  return true;
}

const killHit = (t, kill) => (t.mode === "token" ? kill.tokenUuids.includes(t.uuid) : (kill.actorKeys.includes(t.uuid) || sameName(kill.name, t.name)));
async function failOnKill(kill) {
  const hits = [];
  for (const [bucket, mine] of Object.entries(S())) {
    for (const [qid, st] of Object.entries(mine)) {
      if (st.status !== "active") continue;
      const q = Q().find(x => x.id === qid);
      const f = (q?.failWhen ?? []).find(x => x.track?.uuid && killHit(x.track, kill));
      if (f) hits.push({ bucket, q, f });
    }
  }
  for (const h of hits) await failQuest(h.q, h.bucket, h.f.text);
}

/* ---------- Routing: players ask, the active GM applies ---------- */
function route(m) {
  const gm = game.users.activeGM;
  if (!gm) return ui.notifications.warn("A GM must be online to handle quests.");
  if (gm.isSelf) return enqueue(() => apply(m, game.user.id));
  game.socket.emit(CH, { ...m, sender: game.user.id });
}

function sendFx(target, type, id, text) {
  const m = { action: "fx", user: target, type, id, text };
  game.socket.emit(CH, m);
  if (target === "all" || target === game.user.id) showFx(m);
}

function showFx(m) {
  if (m.type === "accept" || m.type === "complete" || m.type === "fail") playSfx(m.type);
  if (board?.rendered) { fx = m; board.render(); } else if (m.type !== "advance") ui.notifications.info(m.text);
}

async function apply(m, uid) {
  const user = game.users.get(uid);
  if (!user) return;
  if (m.action === "give" || m.action === "discard") return handleLoot(m, user);

  const q = Q().find(x => x.id === m.id);
  if (!q) return;
  if (!user.isGM && secretOf(q) && !q.revealed) return;
  const stages = stagesOf(q), last = stages.length - 1;
  const state = foundry.utils.deepClone(S());
  const bucket = (m.action === "prog" || m.action === "fail") ? m.bucket : bucketOf(q, uid);
  const mine = (state[bucket] ??= {});
  const cur = mine[q.id];
  const target = scopeOf(q) === "party" ? "all" : uid;

  if (m.action === "accept" && !cur) {
    await acceptQuest(q, uid);
  } else if (m.action === "cancel" && cur?.status === "active") {
    delete mine[q.id];
    await game.settings.set(ID, "state", state);
    await syncJournal(bucket, q, null);
  } else if (m.action === "prog" && user.isGM && cur?.status === "active") {
    const objs = stages[stageIndex(q, cur)].objectives;
    const oi = Number(m.obj) || 0;
    if (!objs[oi] || objs[oi].track?.uuid) return;
    const arr = ensureProg(cur, objs.length);
    arr[oi] = Math.min(needed(objs[oi]), Math.max(0, arr[oi] + m.delta));
    await game.settings.set(ID, "state", state);
    await syncJournal(bucket, q, cur);
  } else if (m.action === "fail" && user.isGM && cur?.status === "active") {
    await failQuest(q, bucket, m.reason ?? "");
  } else if (m.action === "report" && cur?.status === "active" && stageMet(q, cur)
    && !(q.reportToGiver && !user.isGM && !m.viaGiver && stageIndex(q, cur) === last)) {
    const si = stageIndex(q, cur);
    if (si < last) {
      cur.stage = si + 1;
      cur.progress = zeros(stages[si + 1]);
      cur.kills = {};
      recompute(state);
      await game.settings.set(ID, "state", state);
      await syncJournal(bucket, q, cur);
      const next = stages[si + 1].name;
      await ChatMessage.create({ content: `<em>${esc(q.title)}</em> has progressed to step ${si + 2} of ${stages.length}: <strong>${esc(next)}</strong>.` });
      sendFx(target, "advance", q.id, `Step ${si + 2}: ${next}`);
      sendBanner(target, "Quest updated", `${q.title}: ${next}`, q.id, "log");
    } else {
      const done = { ...cur, status: "done" };
      if (q.once) mine[q.id] = done; else delete mine[q.id];
      await game.settings.set(ID, "state", state);
      await syncJournal(bucket, q, done);
      await reward(user, q);
      sendFx(target, "complete", q.id, `Completed: ${q.title}`);
    }
  }
}

/* ---------- Automatic objectives: kills, held items, quest-starting items ---------- */
let moduleReady = false;
const isGMClient = () => !!game.users.activeGM?.isSelf;
const sameName = (a, b) => !!a && !!b && String(a).trim().toLowerCase() === String(b).trim().toLowerCase();

/* Items are copied when they reach an inventory, so a copy is matched to its source by any of these. */
const itemKeys = item => [item.getFlag?.(ID, "source"), item._stats?.compendiumSource, item._stats?.duplicateSource, item.flags?.core?.sourceId, item.uuid].filter(Boolean);
function linkMatches(item, link) {
  if (!link?.uuid) return false;
  if (itemKeys(item).includes(link.uuid)) return true;
  return sameName(item.name, link.name) && (!link.type || item.type === link.type);
}
/* Stamp the source item so every copy carries a link back to it. */
async function stampSource(doc) {
  if (doc?.documentName !== "Item" || doc.pack) return;
  try { if (doc.getFlag(ID, "source") !== doc.uuid) await doc.setFlag(ID, "source", doc.uuid); } catch (e) { console.warn(`${ID} | could not tag ${doc.name}`, e); }
}

function ownerOf(actor) {
  return game.users.find(u => !u.isGM && u.character?.id === actor.id) ?? game.users.find(u => !u.isGM && actor.testUserPermission?.(u, "OWNER"));
}
const partyItem = item => item.parent?.documentName === "Actor" && partyActors().some(a => a.id === item.parent.id);

/* How many of an item the party (or, for a personal quest, that player) is holding right now. */
function heldBy(bucket, link) {
  const actors = bucket === "party" ? partyActors() : [game.users.get(bucket)?.character].filter(Boolean);
  let n = 0;
  for (const a of actors) for (const it of a.items) if (linkMatches(it, link)) n += Math.max(0, Number(it.system?.quantity ?? 1) || 0);
  return n;
}

/* Re-count every held-item objective. Mutates the given state copy and returns what changed. */
function recompute(state) {
  const touched = [];
  for (const [bucket, mine] of Object.entries(state)) {
    for (const [qid, st] of Object.entries(mine)) {
      if (st.status !== "active") continue;
      const q = Q().find(x => x.id === qid);
      if (!q) continue;
      const objs = stagesOf(q)[stageIndex(q, st)].objectives;
      objs.forEach((o, i) => {
        if (o.track?.kind !== "item" || !o.track.uuid) return;
        const v = Math.min(needed(o), heldBy(bucket, o.track));
        const arr = ensureProg(st, objs.length);
        if (arr[i] !== v) { arr[i] = v; touched.push({ bucket, q, st }); }
      });
    }
  }
  return touched;
}

async function syncTracked() {
  const state = foundry.utils.deepClone(S());
  const touched = recompute(state);
  if (!touched.length) return;
  await game.settings.set(ID, "state", state);
  for (const t of touched) await syncJournal(t.bucket, t.q, t.st);
}

async function acceptQuest(q, uid) {
  const state = foundry.utils.deepClone(S());
  const bucket = bucketOf(q, uid);
  const mine = (state[bucket] ??= {});
  if (mine[q.id]) return false;
  if (activeCount(state.party) + activeCount(state[uid]) >= game.settings.get(ID, "slots")) {
    sendFx(uid, "full", q.id, "All quest slots are full.");
    return false;
  }
  mine[q.id] = { status: "active", stage: 0, progress: zeros(stagesOf(q)[0]) };
  recompute(state);
  await game.settings.set(ID, "state", state);
  await syncJournal(bucket, q, mine[q.id]);
  sendFx(scopeOf(q) === "party" ? "all" : uid, "accept", q.id, `Accepted: ${q.title}`);
  return true;
}

/* A party character just received an item: it may start (reveal and/or accept) a quest. */
async function itemFound(item) {
  const owner = ownerOf(item.parent);
  for (const q of Q()) {
    if (!(q.startItems ?? []).some(l => linkMatches(item, l))) continue;
    let current = q;
    if (secretOf(q) && !q.revealed) {
      await game.settings.set(ID, "quests", Q().map(x => (x.id === q.id ? { ...x, revealed: true } : x)));
      sendBanner(scopeOf(q) === "party" ? "all" : (owner?.id ?? "all"), "Secret quest unlocked!", q.title, q.id);
      current = Q().find(x => x.id === q.id) ?? q;
    }
    if (q.autoAccept) await acceptQuest(current, owner?.id ?? game.user.id);
  }
}

/* A monster just fell: credit every active kill objective that matches it. */
function killTargets(actor, tokenDoc) {
  const token = tokenDoc ?? actor.token ?? null;
  const base = actor.token?.baseActor ?? actor;
  const tokenUuids = token ? [token.uuid] : (actor.getActiveTokens?.(false, true) ?? []).map(t => t.uuid);
  return {
    tokenUuids, name: base.name, key: tokenUuids[0] ?? base.uuid,
    actorKeys: [base.uuid, base._stats?.compendiumSource, base.flags?.core?.sourceId].filter(Boolean)
  };
}

async function handleKill(actor, tokenDoc) {
  if (!actor || actor.type === "character") return;
  const kill = killTargets(actor, tokenDoc);
  await failOnKill(kill);
  const state = foundry.utils.deepClone(S());
  const touched = [];
  for (const [bucket, mine] of Object.entries(state)) {
    for (const [qid, st] of Object.entries(mine)) {
      if (st.status !== "active") continue;
      const q = Q().find(x => x.id === qid);
      if (!q) continue;
      const objs = stagesOf(q)[stageIndex(q, st)].objectives;
      objs.forEach((o, i) => {
        const t = o.track;
        if (t?.kind !== "kill" || !t.uuid) return;
        const hit = t.mode === "token" ? kill.tokenUuids.includes(t.uuid) : (kill.actorKeys.includes(t.uuid) || sameName(kill.name, t.name));
        if (!hit) return;
        const seen = ((st.kills ??= {})[i] ??= []);
        if (seen.includes(kill.key)) return;
        seen.push(kill.key);
        const arr = ensureProg(st, objs.length);
        arr[i] = Math.min(needed(o), (arr[i] ?? 0) + 1);
        touched.push({ bucket, q, st });
      });
    }
  }
  if (!touched.length) return;
  await game.settings.set(ID, "state", state);
  for (const t of touched) await syncJournal(t.bucket, t.q, t.st);
}

Hooks.on("createItem", item => {
  if (!moduleReady || !isGMClient() || !partyItem(item)) return;
  enqueue(async () => { await itemFound(item); await syncTracked(); });
});
Hooks.on("updateItem", item => { if (moduleReady && isGMClient() && partyItem(item)) enqueue(syncTracked); });
Hooks.on("deleteItem", item => { if (moduleReady && isGMClient() && partyItem(item)) enqueue(syncTracked); });
Hooks.on("updateActor", (actor, changes) => {
  if (!moduleReady || !isGMClient()) return;
  const hp = foundry.utils.getProperty(changes, "system.attributes.hp.value");
  if (hp === undefined || hp > 0) return;
  enqueue(() => handleKill(actor));
});
Hooks.on("updateToken", (token, changes) => {
  if (!moduleReady || !isGMClient()) return;
  const hp = foundry.utils.getProperty(changes, "delta.system.attributes.hp.value");
  if (hp === undefined || hp > 0 || !token.actor) return;
  enqueue(() => handleKill(token.actor, token));
});
Hooks.on("createActiveEffect", effect => {
  if (!moduleReady || !isGMClient() || !effect.statuses?.has("dead") || effect.parent?.documentName !== "Actor") return;
  enqueue(() => handleKill(effect.parent));
});
Hooks.on("updateCombatant", (combatant, changes) => {
  if (!moduleReady || !isGMClient() || changes.defeated !== true) return;
  enqueue(() => handleKill(combatant.actor, combatant.token));
});

/* ---------- Rewards and loot ---------- */
async function giveItem(actor, entry) {
  const src = await fromUuid(entry.uuid);
  if (!src) { ui.notifications.warn(`“${entry.name}” no longer exists, so it could not be given out.`); return false; }
  const data = src.toObject();
  for (const k of ["_id", "folder", "sort", "ownership"]) delete data[k];
  data.flags = { ...(data.flags ?? {}), [ID]: { ...(data.flags?.[ID] ?? {}), source: entry.uuid } };
  if (data.system && "quantity" in data.system) data.system.quantity = entry.qty;
  await actor.createEmbeddedDocuments("Item", [data]);
  return true;
}

async function reward(user, q) {
  const cur = game.settings.get(ID, "currency");
  const party = scopeOf(q) === "party";
  const recipients = party ? partyActors() : [user.character].filter(Boolean);
  const lines = [];

  if (q.gold && CURRENCIES.includes(cur) && recipients.length) {
    const each = Math.floor(q.gold / recipients.length);
    const rest = q.gold - each * recipients.length;
    const lead = Math.max(0, recipients.findIndex(a => a.id === user.character?.id));
    for (const [i, a] of recipients.entries()) {
      const add = each + (i === lead ? rest : 0);
      await a.update({ [`system.currency.${cur}`]: (a.system.currency?.[cur] ?? 0) + add });
    }
    lines.push(`${q.gold} ${cur}${recipients.length > 1 ? ` split between ${recipients.length} characters` : ""}`);
  } else if (q.gold) lines.push(`${q.gold} ${cur}`);

  const stash = [];
  const given = [];
  for (const it of q.items ?? []) {
    if (!party && user.character && await giveItem(user.character, it)) given.push(itemLabel(it));
    else stash.push({ id: foundry.utils.randomID(), quest: q.title, ...it });
  }
  if (given.length) lines.push(`${given.join(", ")} added to ${user.character.name}`);
  if (stash.length) {
    await game.settings.set(ID, "loot", [...LOOT(), ...stash]);
    lines.push(`Waiting in Party Loot: ${stash.map(itemLabel).join(", ")}`);
  }
  if (q.item) lines.push(q.item);

  const who = party ? `The party (reported by ${esc(user.name)})` : `<strong>${esc(user.name)}</strong>`;
  await ChatMessage.create({ content: `${who} completed <em>${esc(q.title)}</em>.${lines.length ? ` Reward: ${lines.map(esc).join("; ")}.` : ""}` });

  if (stash.length) {
    game.socket.emit(CH, { action: "loot" });
    openLoot();
  }
}

async function handleLoot(m, user) {
  const loot = LOOT();
  const entry = loot.find(l => l.id === m.loot);
  if (!entry) return;
  if (m.action === "discard") {
    if (!user.isGM) return;
    return game.settings.set(ID, "loot", loot.filter(l => l.id !== entry.id));
  }
  const actor = partyActors().find(a => a.id === m.actor);
  if (!actor) return;
  if (!(await giveItem(actor, entry))) return;
  await game.settings.set(ID, "loot", loot.filter(l => l.id !== entry.id));
  await ChatMessage.create({ content: `<strong>${esc(user.name)}</strong> gave <em>${esc(itemLabel(entry))}</em> to <strong>${esc(actor.name)}</strong>.` });
}

/* ---------- Quest journals (one shared party journal, plus one per player for personal quests) ---------- */
async function syncJournal(bucket, q, st) {
  let j = game.journal.find(e => e.getFlag(ID, "owner") === bucket);
  if (!j) {
    if (!st) return;
    const party = bucket === "party";
    j = await JournalEntry.create({
      name: party ? "Quest Journal – Party" : `Quest Journal – ${game.users.get(bucket)?.name ?? "Player"}`,
      ownership: party ? { default: OBSERVER() } : { default: 0, [bucket]: OBSERVER() },
      flags: { [ID]: { owner: bucket } }
    });
  }
  const page = j.pages.find(p => p.getFlag(ID, "quest") === q.id);
  if (!st) return page?.delete();

  const cur = game.settings.get(ID, "currency");
  const stages = stagesOf(q), last = stages.length - 1;
  const done = st.status === "done";
  const si = done ? last : stageIndex(q, st);
  const failed = st.status === "failed";
  const status = failed ? "Failed" : done ? "Completed" : stages.length > 1 ? `Step ${si + 1} of ${stages.length}` : "In progress";
  const past = stages.slice(0, done ? stages.length : si).map(s => `<li>✓ ${esc(s.name)}</li>`).join("");
  const now = done || failed ? "" : (() => {
    const s = stages[si];
    const lis = s.objectives.map((o, i) => ({ o, i })).filter(({ o }) => isOpen(o))
      .map(({ o, i }) => `<li>${esc(o.text)}: ${Math.min(getProg(st, i), needed(o))} / ${needed(o)}</li>`).join("");
    return `<p><strong>${esc(stages.length > 1 ? s.name : "Objectives")}</strong></p>${s.desc ? `<p>${esc(s.desc).replace(/\n/g, "<br>")}</p>` : ""}<ul>${lis}</ul>`;
  })();
  const rewards = [q.gold ? `${q.gold} ${cur}` : "", ...(q.items ?? []).map(itemLabel), q.item].filter(Boolean).map(esc).join(", ") || "None";
  const html = `<p><em>${TYPES[qualOf(q)]} · ${esc(q.kind)}</em></p><p><strong>Status:</strong> ${status}</p>
    <p><strong>Client:</strong> ${esc(q.giver)} (${esc(q.location)})</p><p>${esc(q.desc).replace(/\n/g, "<br>")}</p>
    ${past ? `<p><strong>Completed steps</strong></p><ul>${past}</ul>` : ""}${now}
    <p><strong>Reward:</strong> ${rewards}</p>`;
  if (page) await page.update({ name: q.title, "text.content": html });
  else await j.createEmbeddedDocuments("JournalEntryPage", [{ name: q.title, type: "text", text: { format: 1, content: html }, flags: { [ID]: { quest: q.id } } }]);
}

async function resyncJournals(q) {
  for (const [bucket, mine] of Object.entries(S())) if (mine[q.id]) await syncJournal(bucket, q, mine[q.id]);
}

async function purgeQuest(id) {
  const state = foundry.utils.deepClone(S());
  for (const b of Object.values(state)) delete b[id];
  await game.settings.set(ID, "state", state);
  for (const j of game.journal.filter(e => e.getFlag(ID, "owner"))) {
    const ids = j.pages.filter(p => p.getFlag(ID, "quest") === id).map(p => p.id);
    if (ids.length) await j.deleteEmbeddedDocuments("JournalEntryPage", ids);
  }
}

/* ---------- Hooks ---------- */
Hooks.once("init", () => {
  const reg = (k, d, extra = {}) => game.settings.register(ID, k, { scope: "world", config: false, default: d, onChange: refresh, ...extra });
  reg("quests", [], { type: Array });
  reg("state", {}, { type: Object });
  reg("loot", [], { type: Array });
  const creg = (k, d, extra = {}) => game.settings.register(ID, k, { scope: "client", config: false, default: d, onChange: refresh, ...extra });
  creg("trackerShow", true, { type: Boolean, config: true, name: "Show quest tracker", hint: "Keep the quest tracker on screen. Drag its header to move it." });
  creg("uiStyle", "default", { type: String, config: true, name: "Quest UI style", hint: "Your own look for the quest board, log, tracker and banners.", choices: { default: "Use the world default", gold: "Gold & black", parchment: "Parchment" } });
  creg("sfxVolume", 0.8, { type: Number, config: true, range: { min: 0, max: 1, step: 0.05 }, name: "Quest sound effect volume" });
  creg("musicVolume", 0.5, { type: Number, config: true, range: { min: 0, max: 1, step: 0.05 }, name: "Quest board music volume", onChange: v => { if (boardMusic) boardMusic.volume = v; } });
  creg("musicMuted", false, { type: Boolean, onChange: musicSettingChanged });
  creg("trackerCollapsed", false, { type: Boolean });
  creg("trackerPos", {}, { type: Object, onChange: renderTracker });
  creg("untracked", [], { type: Array });
  reg("defaultStyle", "gold", { type: String, config: true, name: "Default quest UI style", hint: "Used by players who leave their own style on 'Use the world default'.", choices: { gold: "Gold & black", parchment: "Parchment" } });
  const snd = (k, name, hint) => reg(k, "", { type: String, config: true, name, hint, filePicker: "audio", onChange: k === "musicBoard" ? musicSettingChanged : () => {} });
  snd("sfxAccept", "Sound: quest accepted", "Played for players when a quest is accepted. Leave empty for silence.");
  snd("sfxProgress", "Sound: quest progressed", "Played when an objective advances or a quest moves to its next step.");
  snd("sfxComplete", "Sound: quest completed", "Played when a quest is completed.");
  snd("sfxFail", "Sound: quest failed", "Played when a quest is failed.");
  snd("musicBoard", "Quest board music", "Loops while the quest board is open and stops when it closes. The quest log and tracker stay silent.");
  reg("slots", 10, { type: Number, config: true, name: "Quest slots per player" });
  reg("currency", "gp", { type: String, config: true, name: "Currency label", hint: "Use gp, sp, etc. to auto-add the reward to character sheets." });
  foundry.applications.handlebars.loadTemplates([`modules/${ID}/templates/board.hbs`, `modules/${ID}/templates/loot.hbs`, `modules/${ID}/templates/log.hbs`, `modules/${ID}/templates/offer.hbs`]);
});

Hooks.once("ready", () => {
  game.modules.get(ID).api = { open: openBoard, openLoot, openLog, speakTo, offer: gmOffer };
  applyTheme();
  progSnap = snapProgress();
  trackerReady = true;
  moduleReady = true;
  if (isGMClient()) enqueue(syncTracked);
  renderTracker();
  window.addEventListener("resize", () => { if (trackerEl && !trackerEl.hidden) placeTracker(); });
  game.socket.on(CH, m => {
    if (m.action === "fx") { if (m.user === "all" || m.user === game.user.id) showFx(m); }
    else if (m.action === "banner") { if (m.user === "all" || m.user === game.user.id) showBanner(m); }
    else if (m.action === "loot") openLoot();
    else if (m.action === "offer") { if (!game.user.isGM && (m.user === "all" || m.user === game.user.id)) openOffer(m); }
    else if (game.users.activeGM?.isSelf) enqueue(() => apply(m, m.sender));
  });
});

Hooks.on("getSceneControlButtons", controls => {
  const tools = controls.tokens?.tools;
  if (!tools) return;
  tools.questBoard = { name: "questBoard", title: "Quest Board", icon: "fa-solid fa-scroll", order: 99, button: true, visible: true, onChange: () => openBoard() };
  tools.questGiver = { name: "questGiver", title: "Quest giver: speak to the targeted NPC (GM: the selected token)", icon: "fa-solid fa-comments", order: 101, button: true, visible: true,
    onChange: () => speakTo((game.user.isGM ? canvas.tokens?.controlled?.[0] : null)?.actor ?? [...(game.user.targets ?? [])][0]?.actor) };
  tools.questLog = { name: "questLog", title: "Quest Log", icon: "fa-solid fa-book-open", order: 100, button: true, visible: true, onChange: () => openLog() };
});

/* GM: an "Offer a quest" button on NPC tokens that have quests assigned. */
Hooks.on("renderTokenHUD", (hud, html) => {
  if (!game.user.isGM) return;
  const actor = hud.object?.actor;
  if (!actor || !giverQuests(actorLink(actor)).length) return;
  const root = html instanceof HTMLElement ? html : html?.[0];
  if (!root) return;
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "control-icon";
  btn.title = "Offer a quest";
  btn.innerHTML = '<i class="fa-solid fa-scroll"></i>';
  btn.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); gmOffer(actorLink(actor)); });
  (root.querySelector(".col.left") ?? root).append(btn);
});

/* Everyone: a "Quests" entry in an NPC sheet's header menu. */
Hooks.on("getHeaderControlsApplicationV2", (app, controls) => {
  const actor = app.document;
  if (actor?.documentName !== "Actor" || actor.type === "character") return;
  controls.push({
    icon: "fa-solid fa-scroll", label: game.user.isGM ? "Offer a quest" : "Ask about quests", action: "qbSpeak",
    visible: () => giverQuests(actorLink(actor)).length > 0, onClick: () => speakTo(actor)
  });
});
